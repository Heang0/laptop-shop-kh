import { Component } from '@angular/core';
import { IonContent, IonHeader, IonIcon, IonToolbar } from '@ionic/angular/standalone';

interface Laptop {
  name: string;
  price: string;
  image: string;
  category: string;
  badge?: string;
}

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonHeader, IonToolbar, IonContent, IonIcon],
})
export class HomePage {
  selectedCategory = 'Laptop';

  featured = {
    title: 'Collection of 2026',
    subtitle: 'Curated picks for modern pros who move fast',
    launches: '137 Laptops',
    image:
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80',
  };

  categories = ['Laptop', 'Desktop', 'Gadget', 'Accessories'];

  popularProducts: Laptop[] = [
    {
      name: 'MacBook Air',
      price: '$999',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&q=80',
      category: 'Laptop',
      badge: 'Most Loved',
    },
    {
      name: 'Lenovo ThinkPad',
      price: '$1,199',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&q=80',
      category: 'Laptop',
    },
    {
      name: 'Razer Blade 15',
      price: '$2,399',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&q=80',
      category: 'Laptop',
    },
    {
      name: 'Dell UltraSharp',
      price: '$1,499',
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=400&q=80',
      category: 'Desktop',
    },
    {
      name: 'Studio Display',
      price: '$1,599',
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=400&q=80',
      category: 'Accessories',
    },
    {
      name: 'Surface Studio',
      price: '$3,499',
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=400&q=80',
      category: 'Desktop',
    },
  ];

  bestSellers: Laptop[] = [
    {
      name: 'MacBook Air',
      price: '$999',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&q=80',
      category: 'Laptop',
    },
    {
      name: 'Lenovo Yoga 9i',
      price: '$1,749',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&q=80',
      category: 'Laptop',
    },
    {
      name: 'Galaxy Book Pro',
      price: '$1,299',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&q=80',
      category: 'Laptop',
    },
  ];

  get filteredProducts() {
    return this.popularProducts.filter((product) => product.category === this.selectedCategory);
  }

  selectCategory(category: string) {
    this.selectedCategory = category;
  }
}
